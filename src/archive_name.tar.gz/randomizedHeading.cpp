#include "randomizedHeading.hpp"
#include "utils.hpp"
#include <cmath>


semirandomHeading::semirandomHeading(){
    //random enough
    unsigned seed = std::chrono::steady_clock::now().time_since_epoch().count();
    randGen.seed(seed);                // <--- seed the RNG

    std::uniform_int_distribution<int> tmp(-5,5);
    randInt = tmp;
    // initialize as a relative offset
    Vec2 temp = getFullRandom();
    randomHead = temp;
}

Vec2 semirandomHeading::getFullRandom(){
    int tempX = randInt(randGen);
    int tempY = randInt(randGen);

    Vec2 temp;
    if(tempX>=0){
        temp.x = static_cast<int>(30.0+30.0*(tempX/5.0));
    }else{
        temp.x = static_cast<int>(-30.0+30.0*(tempX/5.0));
    }

    if(tempY<0){
        temp.y = static_cast<int>(30.0+30.0*(tempY/5.0));
    }else{
        temp.y = static_cast<int>(-30.0+30.0*(tempY/5.0));
    }

    // store as a relative offset
    randomHead = temp;

    return temp;
    
}



Vec2 semirandomHeading::fortyFiveCcWise(){
    const double c = std::sqrt(2.0) / 2.0;
    const double s = c;

    double nx = randomHead.x * c - randomHead.y * s;
    double ny = randomHead.x * s + randomHead.y * c;

    randomHead.x = static_cast<int>(std::round(nx));
    randomHead.y = static_cast<int>(std::round(ny));

    return randomHead;
}

Vec2 semirandomHeading::fortyFiveCwise(){
    const double c = std::sqrt(2.0) / 2.0;
    const double s = -c;

    double nx = randomHead.x * c - randomHead.y * s;
    double ny = randomHead.x * s + randomHead.y * c;

    randomHead.x = static_cast<int>(std::round(nx));
    randomHead.y = static_cast<int>(std::round(ny));

    // return offset (not absolute)
    return randomHead;
}


void semirandomHeading::iterate( Vec2 cPos, Vec2 absDir){
    // Always refresh or adjust the relative offset so discovery produces new targets

    std::cout<<"Prior "<<prior.to_string()<<std::endl;
    std::cout<<"PriorPrior "<<priorPrior.to_string()<<std::endl;

    if(prior==cPos and priorPrior==prior){
        //std::cout<<"Prior "<<prior.to_string()<<std::endl;
    //std::cout<<"PriorPrior "<<priorPrior.to_string()<<std::endl;

        randomHead = getFullRandom();
        priorPrior=prior;
        prior=cPos;
    }
    priorPrior=prior;
    prior=cPos;
    return;

        /*
        if(averageHeading.x>=0.0 && averageHeading.y>=0.0){
            fortyFiveCcWise();
            //fortyFiveCcWise();
            return;
        }

        if(averageHeading.x<0.0 && averageHeading.y > 0.0){
            fortyFiveCwise();
            //randomHead = cPos+fortyFiveCwise();
            return;
        }

        if(averageHeading.x<0.0 && averageHeading.y < 0.0){
            fortyFiveCcWise();
            randomHead = cPos+fortyFiveCcWise();
            return;
        }

        if(averageHeading.x>=0.0 && averageHeading.y<=0.0){
            fortyFiveCwise();
            //randomHead = cPos+fortyFiveCwise();
            return;
        }

        randomHead = getFullRandom();
        std::cout<<"full random applied during wall bump recovery"<<std::endl;
        return;

    // (so the randomizer actually changes targets between discovery calls)

    pastSeven.push_back(absDir);
    while(pastSeven.size() > 7) pastSeven.pop_front();

    double sumx = 0.0, sumy = 0.0;
    for(const Vec2 &v : pastSeven){
        sumx += static_cast<double>(v.x);
        sumy += static_cast<double>(v.y);
    }
    if(!pastSeven.empty()){*/
       // averageHeading.x = sumx / static_cast<double>(pastSeven.size());
      //  averageHeading.y = sumy / static_cast<double>(pastSeven.size());
    //} else {
        //averageHeading.x = 0.0;
      //  averageHeading.y = 0.0;
    //}

    //std::cout<<averageHeading.x<<std::endl;
    //std::cout<<averageHeading.y<<std::endl;
    //return;



    }


Vec2 semirandomHeading::getNext(Vec2 cAbsPos){

    //if i move theese in small increments to the absolute position they wont have to dump a lot of node guesses early
    //also keeps the queues shorter
    
    increment = cAbsPos;
    increment.x=randomHead.x/10;
    increment.y=randomHead.y/10;

    if(increment==cAbsPos){
        increment.x += randomHead.x/10;
        increment.y += randomHead.y/10;
    }

    std::cout<<"AI is at:"<<cAbsPos.to_string()<<std::endl;
    std::cout<<"Heading towards: "<<increment.to_string()<<std::endl;
    return increment;
}

