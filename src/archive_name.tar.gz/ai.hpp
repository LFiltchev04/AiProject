#pragma once

#include<algorithm>
#include<string>
#include<random>
#include<map>
#include<cstdlib>
#include<iostream>
#include"percepts.hpp"
#include"comm.hpp"
#include "pathfinderClasses.hpp"
#include "randomizedHeading.hpp"
#include "utils.hpp"


class AI {
    
    
    Vec2 tgt;

    //this is dead but the dead elements to whhich it refers are not removed so it stays
    int wallBumps = 0;
    char state;
protected:
    // Necessary, do not delete.
    unsigned id;
    unsigned agent_speed;
    std::mt19937_64* rng;
public:
    semirandomHeading semiRand;
    
    AI();
    AI(
        unsigned id, 
        unsigned agent_speed,
        std::mt19937_64* rng
    );
    virtual std::vector<std::string> Run(
        Percepts & percepts,
        AgentComm * comms
    );
    //i pretty much just went whatever with the class hirearchy, all the code for pathfinding and map update/iteration is accessible solely trought this object, its extremely ugly
    //the pathfinder and the map object are quite coupled and as a result the function calls to get to anything are long and very ugly.
    pathfinder pFind;

     std::string discoveryMode();

    //allows multiple moves per turn in areas that are seen
    std::vector<std::string> traverseMode();

    

    Vec2 randomHead();

    void setMode(char,int);
    std::vector<std::string> traverseMode(int);
    std::string discovery();

    std::string runModel();


};



